﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Tools
{
    public static class ErrorLog
    {
        public static void write(string stackTrace, string message)
        {

        }
    }
}
