﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.DTO
{
    public class BooksDTO
    {
        public int bookid { get; set; }
        public string bookname { get; set; }
        public string authorname { get; set; }
        public float bookprice { get; set; }
        public string picture { get; set; }
    }
}
