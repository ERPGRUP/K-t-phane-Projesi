﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Project.DTO;
using static Project.Repository.BusinessRepositories;

namespace Project.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        BooksRepository _booksRep;
        public BooksController(BooksRepository books)
        {
            _booksRep = books;
        }
        [HttpGet("GetBooks")]
        public ICollection<BooksDTO> GetBooks()
        {
            return _booksRep.Bring();
        }
    }
}