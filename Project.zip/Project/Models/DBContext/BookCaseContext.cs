﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Models.DBContext
{
    public class BookCaseContext : DbContext
    {
        public BookCaseContext(DbContextOptions<BookCaseContext> op):base(op)
        {

        }
        DbSet<Categories> categories { get; set; }
        DbSet<Books> books { get; set; }
        DbSet<Stock> stock { get; set; }
        DbSet<User> user { get; set; }
        DbSet<ShoppingBox> shoppingBox { get; set; }
        DbSet<Order> order { get; set; }
        DbSet<OrderDetails> orderDetails { get; set; }


        public class Categories
        {
            [Key]
            public int CategoryID { get; set; }
            public string CategoryName { get; set; }

            public  ICollection<Books> BookList { get; set; }
        }
        
        public class Books
        {
            [Key]
            public int BookID { get; set; }
            public string BookName { get; set; }
            public int QuantityPerUnit { get; set; }
            public float BookPrice { get; set; }
            public string Author { get; set; }
            public string PictureUrl { get; set; }


            public int CategoryID { get; set; }
            [ForeignKey("CategoryID")]
            public Categories Categories { get; set; }

            public  ICollection<Stock> StockList { get; set; }
            public  ICollection<ShoppingBox> ShoppingBoxList { get; set; }
            public  ICollection<OrderDetails> OrderDetailsList { get; set; }
        }
        public class Stock
        {
            [Key]
            public int StockID { get; set; }
            public DateTime DateOfBuy { get; set; }
            public int QuantityPerUnit { get; set; }
            public float PriceOfBuy { get; set; }

            public int BookID { get; set; }
            [ForeignKey("BookID")]
            public Books Books { get; set; }
           

            public User User { get; set; }
            public int UserID { get; set; }

        }
        
        public class User
        {
            [Key]
            public int UserID { get; set; }
            public string UserName { get; set; }
            public string Password { get; set; }
            public string NameAndSurname { get; set; }
            public int AuthorityID { get; set; }

            public ICollection<Stock> StockList { get; set; }

            public ICollection<OrderDetails> OrderDetailsList { get; set; }
        }

        public class ShoppingBox
        {
            [Key]
            public int ShoppingBoxID { get; set; }
            public int QuantityPerUnit { get; set; }
            public float Price { get; set; }

            public int BookID { get; set; }
            [ForeignKey("BookID")]
            public Books Books { get; set; }


        }

        public class Order
        {
            [Key]
            public int OrderID { get; set; }
            public int UserID { get; set; }
            public DateTime OrderDate { get; set; }
            public float TotalAmount { get; set; }

            [ForeignKey("UserID")]
            public User User { get; set; }

            public ICollection<OrderDetails> OrderDetailList { get; set; }
        }

        public class OrderDetails
        {
            [DatabaseGenerated(DatabaseGeneratedOption.None)]
            [Key]

            public int OrderDetailsID { get; set; }
            public int OrderID { get; set; }
            public int BookID { get; set; }
            public int QuantityPerUnit { get; set; }
            [ForeignKey("OrderID")]
            public Order Order { get; set; }
            [ForeignKey("BookID")]
            public Books Books { get; set; }
        }
    }
}