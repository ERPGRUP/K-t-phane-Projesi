﻿using Project.DTO;
using Project.Models.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static Project.Models.DBContext.BookCaseContext;

namespace Project.Repository
{
    public class BusinessRepositories
    {
        public class UserRepository:BaseRepository<User>
        {
            public UserRepository(BookCaseContext db):base(db)
            {

            }

            public void UserRegister(User user, int Authority)
            {
                if (user.AuthorityID != 1)
                    user.AuthorityID = 0;
                this.Add(user);
            }
        }
        public class BooksRepository : BaseRepository<Books>
        {
            public BooksRepository(BookCaseContext db):base(db)
            {

            }

            public ICollection<BooksDTO> Bring()
            {
                return Set().Select(x => new BooksDTO
                {
                    bookid = x.BookID,
                    bookname = x.BookName,
                    authorname = x.Author,
                    bookprice = x.BookPrice,
                    picture = x.PictureUrl

                }).ToList();
            }

        }
    }
}
