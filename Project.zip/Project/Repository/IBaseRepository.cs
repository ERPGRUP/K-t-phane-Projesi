﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Repository
{
    public interface IBaseRepository<T> where T: class,new()
    {
        Task<ICollection<T>> GetList();
        Task<T> Find(int id);
        void Add(T entity);
        void Update(T entity);
        void Remove(T entity);
        Task<bool> Commit();
        DbSet<T> Set();
    }
}