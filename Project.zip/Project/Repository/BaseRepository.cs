﻿using Microsoft.EntityFrameworkCore;
using Project.Models.DBContext;
using Project.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Repository
{
    public class BaseRepository<T> : IBaseRepository<T> where T:class,new()
    {
        BookCaseContext _db;
        public BaseRepository(BookCaseContext db)
        {
            _db = db;
        }
        
        public void Add(T entity)
        {
            try
            {
                _db.Entry(entity).State = EntityState.Added;
            }
            catch(Exception e)
            {
                ErrorLog.write(e.StackTrace, e.Message);
            }
        }

        public async Task<T> Find(int id)
        {
            T entity = null;
            try
            {
                 entity= await Set().FindAsync(id);
            }
            catch (Exception e)
            {
                ErrorLog.write(e.StackTrace, e.Message);
            }
            return entity;
        }

        public async Task<ICollection<T>> GetList()
        {
            ICollection<T> list = null;
            try
            {
                list = await Set().ToListAsync();
            }
            catch (Exception e)
            {
                ErrorLog.write(e.StackTrace, e.Message);
            }
            return list;
        }

        public void Remove(T entity)
        {
            try
            {
                _db.Entry(entity).State = EntityState.Deleted;
            }
            catch (Exception e)
            {
                ErrorLog.write(e.StackTrace, e.Message);
            }
        }

        public async Task<bool> Commit()
        {
            return await _db.SaveChangesAsync() > 0;
        }

        public DbSet<T> Set()
        {
            return _db.Set<T>();
        }

        public void Update(T entity)
        {
            try
            {
                _db.Entry(entity).State = EntityState.Modified;
            }
            catch (Exception e)
            {
                ErrorLog.write(e.StackTrace, e.Message);
            }
        }
    }
}
